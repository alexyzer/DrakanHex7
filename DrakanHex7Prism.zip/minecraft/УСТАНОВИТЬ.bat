java -jar packwiz-installer-bootstrap.jar https://raw.githubusercontent.com/alexyzer/DrakanHex7/main/pack/pack.toml -bootstrap-no-update
pause